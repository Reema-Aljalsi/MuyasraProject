//date of creation the classes 22 may by haneen 

package muyasrasystem;

import java.util.ArrayList;

public class MuyasraSystem {

    public static void main(String[] args) {
        
        ArrayList<Trip> trips= new ArrayList<Trip>();// هذي اللسته حنستخدمها لمن الادمن يسوي ادد تريب
        
        ArrayList<User> users= new ArrayList<User>();// --> حنستخدمها لمن نسوي كرييت اكاونت ينضاف اليوزر هنا سواء ادمن او فيسيتور
        
//        ArrayList<Visitor> visitors= new ArrayList<Visitor>();// --> حنستخدمها بعد ما يسوي الفيستور كرريت ينضاف هنا عشان لمن يجي يسوي لوق ان
//        /*
//        كمان عشان لمن يسوي لوق ان يسوي سيرش في هذي الليست في حال كان موجود يدخله على واجهة الفيستور
//        في حال ماكان موجود يدخله تضهر له رسالة منت موجود بالسستم سوي كرييت اكاونت 
//        */
//        ArrayList<Admin> admins= new ArrayList<Admin>();// --> حنستخدمها بعد ما يسوي الفيستور كرريت ينضاف هنا عشان لمن يجي يسوي لوق ان
//        // كمان هنا نفس الكلام للادمن 
        
//______________________________________________________________________________________________________        
        
        //MENU: 1- creat a count , 2- log-in
        
        //if creat a count, are you admin or visitor?? يدخل الانفورمايشن المطلوبة 
       
        //if log in, the system check if its (visitor) or (admin)
             
        //if its ADMIN--> show the menu of admin, 1- add trip, 2- edit , etc..
        // يختار الفنكشن الي يبيها ويسير البروسيس بناءا على طلبه ويسير انتراكشن مع الادمن
           
        //if its VISITOR--> show the menu of visitor, 1- booking trip, 2- delet trip, etc..
        //يختار الفنكشن الي يبيها ويسير البروسيس بناءا على طلبه ويسير انتراكشن مع الفيسيتور 
    }
    
}
